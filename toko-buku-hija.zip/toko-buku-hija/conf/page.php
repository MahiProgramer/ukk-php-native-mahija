<?php

if (isset($_GET['page'])) {
  $page = $_GET['page'];
  switch ($page) {
      // mahasiswa
    case 'data_mahasiswa';
      include 'pages/mahasiswa/data_mahasiswa.php';
      break;
    case 'tambah_mahasiswa':
      include 'pages/mahasiswa/tambah_mahasiswa.php';
      break;
    case 'ubah_mahasiswa';
      include 'pages/mahasiswa/edit_mahasiswa.php';
      break;
      // siswa
    case 'data_siswa';
      include 'pages/siswa/data_siswa.php';
      break;
    case 'tambah_siswa':
      include 'pages/siswa/tambah_siswa.php';
      break;
    case 'ubah_siswa';
      include 'pages/siswa/edit_siswa.php';
      break;
      // Mapel
    case 'data_mapel';
      include 'pages/mapel/data_mapel.php';
      break;
    case 'tambah_mapel':
      include 'pages/mapel/tambah_mapel.php';
      break;
    case 'ubah_mapel';
      include 'pages/mapel/edit_mapel.php';
      break;
      // Guru
    case 'data_guru';
      include 'pages/guru/data_guru.php';
      break;
    case 'tambah_guru':
      include 'pages/guru/tambah_guru.php';
      break;
    case 'ubah_guru';
      include 'pages/guru/edit_guru.php';
      break;
    case 'data_barang';
      include 'pages/barang/data_barang.php';
      break;
    case 'tambah_barang':
      include 'pages/barang/tambah_barang.php';
      break;
    case 'ubah_barang';
      include 'pages/barang/edit_barang.php';
      break;
    case 'data_buku';
      include 'pages/buku/data_buku.php';
      break;
    case 'tambah_buku':
      include 'pages/buku/tambah_buku.php';
      break;
    case 'ubah_buku';
      include 'pages/buku/edit_buku.php';
      break;
    case 'data_distributor';
      include 'pages/distributor/data_distributor.php';
      break;
    case 'tambah_distributor':
      include 'pages/distributor/tambah_distributor.php';
      break;
    case 'ubah_distributor';
      include 'pages/distributor/edit_distributor.php';
      break;
    case 'data_pasok';
      include 'pages/pasok/data_pasok.php';
      break;
    case 'tambah_pasok':
      include 'pages/pasok/tambah_pasok.php';
      break;
    case 'ubah_pasok';
      include 'pages/pasok/edit_pasok.php';
      break;
    case 'data_penjualan';
      include 'pages/penjualan/data_penjualan.php';
      break;
    case 'tambah_penjualan':
      include 'pages/penjualan/tambah_penjualan.php';
      break;
    case 'ubah_penjualan';
      include 'pages/penjualan/edit_penjualan.php';
      break;
    case 'data_kasir';
      include 'pages/kasir/data_kasir.php';
      break;
    case 'tambah_kasir':
      include 'pages/kasir/tambah_kasir.php';
      break;
    case 'ubah_kasir';
      include 'pages/kasir/edit_kasir.php';
      break;
    case 'data_multibarang':
        include 'pages/multibarang/data_multiitem.php';
        break;
    case 'bayar':
        include 'pages/multibarang/bayar.php';
        break;
        
  }
} else {
  //beranda
  include "pages/beranda.php";
}
