<?php
include "../../conf/conn.php";
$id_user = $_GET['id_petugas'];
$query = ("DELETE FROM petugas WHERE id_user ='$id_petugas'");
//echo $query;

if(!mysqli_query($koneksi, "$query")){
die(mysqli_error($koneksi));
}else{
echo '<script>alert("Data Berhasil Dihapus !!!");
window.location.href="../../index.php?page=data_petugas"</script>';
}
?>