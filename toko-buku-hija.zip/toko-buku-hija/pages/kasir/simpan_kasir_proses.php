<?php
include "../../conf/conn.php";
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$telepon = $_POST['telepon'];
$status = $_POST['status'];
$ussername = $_POST['ussername'];
$password = $_POST['password'];
$query = ("INSERT INTO kasir (nama, alamat, telepon, status, ussername, password) VALUE('$nama', '$alamat', '$telepon', '$status', '$ussername', '$password')");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_kasir");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Disimpan!";
  echo "Data Gagal Disimpan !!!";
}
