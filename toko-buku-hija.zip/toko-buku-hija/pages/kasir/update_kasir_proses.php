<?php
include "../../conf/conn.php";
$id = $_POST['id_kasir'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$telepon = $_POST['telepon'];
$status = $_POST['status'];
$ussername = $_POST['ussername'];
$password = $_POST['password'];
$query = ("UPDATE kasir SET nama='$nama', alamat='$alamat', telepon='$telepon', status='$status', ussername='$ussername', password='$password' WHERE id_kasir ='$id'");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_kasir");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Diupate!";
  echo "Data Gagal Diubah !!!";
}
