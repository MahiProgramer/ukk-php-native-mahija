<?php
ob_start();
include "../conf/conn.php";
require_once("../plugins/dompdf/autoload.inc.php");

use Dompdf\Dompdf;
$dompdf = new Dompdf();
$id = isset($_GET['id_buku']) ? mysqli_real_escape_string($koneksi, $_GET['id_buku']) : '';

// Periksa apakah ID buku valid
if (!empty($id)) {
    $query = mysqli_query($koneksi, "SELECT * FROM mahasiswa WHERE id_mahasiswa='$id'");

    // Periksa apakah kueri berhasil dieksekusi
    if ($query) {
        $html = '<center><h3>Daftar Nama Mahasiswa</h3></center><hr/><br/>';
        $html .= '<table border="1" width="100%">
        <tr><th>No</th><th>Judul</th><th>Pengarang</th><th>Penerbit</th><th>Tahun Terbit</th></tr>';
        $no = 1;
        while ($row = mysqli_fetch_array($query)) {
            $html .= "<tr><td>" . $no . "</td><td>" . $row['judul'] . "</td><td>" . $row['pengarang'] . "</td><td>" . $row['penerbit'] . "</td><td>" . $row['tahun_terbit'] . "</td></tr>";
            $no++;
        }

        $html .= "</table>";
        $dompdf->loadHtml($html);
        // Setting ukuran dan orientasi kertas
        $dompdf->setPaper('A4', 'portrait');
        // Rendering dari HTML Ke PDF
        $dompdf->render();
        // Melakukan output file Pdf
        $dompdf->stream('laporan_buku.pdf');
    } else {
        // Kueri tidak berhasil dieksekusi
        echo "Terjadi kesalahan dalam mengambil data buku.";
    }
} else {
    // ID buku tidak valid atau tidak ada
    echo "ID buku tidak valid atau tidak ada.";
}
?>
