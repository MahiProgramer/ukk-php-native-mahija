<?php
include "../../conf/conn.php";
$id                  = $_POST['id_pasok'];
$id_distributor      = $_POST['id_distributor'];
$id_buku             = $_POST['id_buku'];
$jumlah              = $_POST['jumlah'];
$tanggal              = $_POST['tanggal'];
$query = ("UPDATE pasok SET id_distributor='$id_distributor', id_buku='$id_buku', jumlah='$jumlah', tanggal='$tanggal' WHERE id_pasok ='$id'");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_pasok");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Diupate!";
  echo "Data Gagal Diubah !!!";
}
