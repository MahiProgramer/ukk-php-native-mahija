<?php
include "../../conf/conn.php";
$id = $_POST['distributor'];
$id_buku = $_POST['buku'];
$jumlah = $_POST['jumlah'];
$tanggal = $_POST['tanggal'];
$query = ("INSERT INTO pasok (id_distributor, id_buku, jumlah, tanggal) VALUE('$id', '$id_buku', '$jumlah', '$tanggal')");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_pasok");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Disimpan!";
  echo "Data Gagal Disimpan !!!";
}