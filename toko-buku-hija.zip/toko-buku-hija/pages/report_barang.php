<?php
ob_start();
include "../conf/conn.php";
require_once("../plugins/dompdf/autoload.inc.php");

use Dompdf\Dompdf;

$dompdf = new Dompdf();
//$id = $_GET['id'];
$query = mysqli_query($koneksi, "select * from barang");

$html = '<center><h3>Daftar Data barang</h3></center><hr/><br/>';
$html .= '<table border="1" width="100%">
  <tr>
  <th>#</th>
  <th>Id</th>
  <th>Nama Barang</th>
  <th>Harga</th>
  <th>Stok</th>
  <th>Distributor</th>
  </tr>';
$no = 1;
while ($row = mysqli_fetch_array($query)) {
  $html .= "<tr><td>" . $no . "</td><td>" . $row['id_barang'] . "</td><td>" . $row['nama_barang'] . "</td><td>" . $row['harga'] . "</td><td>" . $row['stok'] . "</td><td>" . $row['distributor'] . "</td></tr>";
  $no++;
}

$html .= "</html>";
$dompdf->loadHtml($html);
// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'potrait');
// Rendering dari HTML Ke PDF
$dompdf->render();
// Melakukan output file Pdf
$dompdf->stream('laporan_barang.pdf');
