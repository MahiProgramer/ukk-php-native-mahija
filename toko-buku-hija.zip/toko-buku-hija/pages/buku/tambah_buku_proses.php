<?php
include "../../conf/conn.php";
if($_POST)
{
$nim = $_POST['judul'];
$nama = $_POST['penerbit'];
$kelas = $_POST['pengarang'];
$jurusan = $_POST['tahun_terbit'];
$query = ("INSERT INTO buku(id_buku,judul,penerbit,pengarang,tahun_terbit) VALUES ('','".$nim."','".$nama."','".$kelas."','".$jurusan."')");
if(!mysqli_query($koneksi, "$query")){
die(mysqli_error($koneksi));
}else{
echo '<script>alert("Data Berhasil Ditambahkan !!!");
window.location.href="../../index.php?page=data_buku"</script>';
}
}
?>