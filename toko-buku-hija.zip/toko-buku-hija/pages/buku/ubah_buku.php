<?php
$query = mysqli_query($koneksi, "SELECT * FROM buku WHERE id_buku='".$_GET['id']."'")
or die(mysqli_error($koneksi));
$row = mysqli_fetch_array($query);
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      UBAH BUKU
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> HOME</a></li>
        <li class="active">UBAH BUKU</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="pages/buku/ubah_buku_proses.php">
              <div class="box-body">
                <input type="hidden" name="id_buku" value="<?php echo $row['id_buku']; ?>">
                <div class="form-group">
                  <label>Judul</label>
                  <input type="text" name="judul" class="form-control" placeholder="judul" value="<?php echo $row['judul']; ?>" required>
                </div>
                <div class="form-group">
                  <label><P>Penerbit</P></label>
                  <input type="text" name="penerbit" class="form-control" placeholder="Nama" value="<?php echo $row['penerbit']; ?>" required>
                </div>
                <div class="form-group">
                <label><P>pengarang</P></label>
                  <input type="text" name="pengarang" class="form-control" placeholder="Nama" value="<?php echo $row['pengarang']; ?>" required>
                </div>
                <div class="form-group">
                <label><P>tahun terbit</P></label>
                  <input type="text" name="tahun_terbit" class="form-control" placeholder="Nama" value="<?php echo $row['tahun_terbit']; ?>" required>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary" title="Simpan Data"> <i class="glyphicon glyphicon-floppy-disk"></i> Simpan</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->