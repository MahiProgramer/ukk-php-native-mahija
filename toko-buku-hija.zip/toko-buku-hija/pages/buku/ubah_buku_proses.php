<?php
include "../../conf/conn.php";
if($_POST)
{
$id = $_POST['id_buku'];
$judul = $_POST['judul'];
$penerbit = $_POST['penerbit'];
$pengarang = $_POST['pengarang'];
$thn = $_POST['tahun_terbit'];
$query = ("UPDATE buku SET judul='$judul',penerbit='$penerbit',pengarang='$pengarang',tahun_terbit='$thn' WHERE id_buku ='$id'");
if(!mysqli_query($koneksi, "$query")){
die(mysqli_error($koneksi));
}else{
echo '<script>alert("Data Berhasil Diubah !!!");
window.location.href="../../index.php?page=data_buku"</script>';
}
}
?>