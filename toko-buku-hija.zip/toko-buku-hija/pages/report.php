<?php
ob_start();
include "../conf/conn.php";
require_once("../plugins/dompdf/autoload.inc.php");

use Dompdf\Dompdf;
$dompdf = new Dompdf();
//$id = $_GET['id'];
$query = mysqli_query($koneksi,"select * from buku ORDER BY id_buku DESC");

$html = '<center><h3>Daftar Judul Buku</h3></center><hr/><br/>';
$html .= '<table border="1" width="100%">
<tr><th>No</th><th>judul</th><th>penerbit</th><th>pengarang</th><th>tahun terbit</th></tr>';
$no = 1;
while($row = mysqli_fetch_array($query))    
{
 $html .= "<tr><td>".$no."</td><td>".$row['judul']."</td><td>".$row['penerbit']."</td><td>".$row['pengarang']."</td><td>".$row['tahun_terbit']."</td></tr>";
 $no++;
}

$html .= "</html>";
$dompdf->loadHtml($html);
// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'potrait');
// Rendering dari HTML Ke PDF
$dompdf->render();
// Melakukan output file Pdf
$dompdf->stream('laporan_buku.pdf');
?>