<?php
include "../../conf/conn.php";
$nim = $_POST['nim'];
$nama = $_POST['nama'];
$kelas = $_POST['kelas'];
$jurusan = $_POST['jurusan'];
$query = "INSERT INTO mahasiswa (nim, nama, kelas, jurusan) VALUE('$nim', '$nama', '$kelas', '$jurusan')";
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_mahasiswa");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Disimpan!";
  echo "Data Gagal Disimpan !!!";
}
