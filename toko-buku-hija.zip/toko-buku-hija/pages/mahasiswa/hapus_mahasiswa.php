<?php
include "../../conf/conn.php";
$id = $_GET['id'];
$query = ("DELETE FROM mahasiswa WHERE id_mahasiswa ='$id'");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_mahasiswa");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Diupate!";
  echo "Data Gagal Diubah !!!";
}
