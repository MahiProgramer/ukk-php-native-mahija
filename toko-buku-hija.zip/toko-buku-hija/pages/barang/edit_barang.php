<?php

include('../crud-php/conf/conn.php');

$id = $_GET['id'];

$query = "SELECT * FROM barang WHERE id_barang = $id LIMIT 1";

$result = mysqli_query($koneksi, $query);

$row = mysqli_fetch_array($result);
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      UBAH BARANG
    </h1>
    <ol class="breadcrumb">
      <li><a href="index.php"><i class="fa fa-dashboard"></i> HOME</a></li>
      <li class="active">UBAH BARANG</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- general form elements -->
        <div class="box box-primary">
          <!-- /.box-header -->
          <!-- form start -->
          <form role="form" method="post" action="pages/barang/update_barang_proses.php">
            <div class="box-body">
              <input type="hidden" name="id" value="<?php echo $row['id_barang']; ?>">
              <div class="form-group">
                <label>Nama Barang</label>
                <input type="text" name="nama_barang" class="form-control" placeholder="nama_barang" value="<?php echo $row['nama_barang']; ?>" required>
              </div>
              <div class="form-group">
                <label>Harga</label>
                <input type="number" name="harga" class="form-control" placeholder="harga" value="<?php echo $row['harga']; ?>" required>
              </div>
              <div class="form-group">
                <label>Stok</label>
              <input type="number" name="stok" class="form-control" placeholder="stok" value="<?php echo $row['stok']; ?>" required> 
              </div>
              <div class="form-group">
              <label>Distributor</label>
                <input type="text" name="distributor" class="form-control" placeholder="distributor" value="<?php echo $row['distributor']; ?>" required>
              </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <button type="submit" class="btn btn-primary" title="Simpan Data"> <i class="glyphicon glyphicon-floppy-disk"></i> Simpan</button>
            </div>
          </form>
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->