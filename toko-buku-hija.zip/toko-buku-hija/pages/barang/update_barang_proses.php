<?php
include "../../conf/conn.php";
$id_barang = $_POST['id_barang'];
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];
$distributor = $_POST['distributor'];
$query = ("UPDATE barang SET nama_barang='$nama_barang',harga='$harga',stok='$stok',distributor='$distributor' WHERE id_barang ='$id_barang'");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_barang");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Diupate!";
  echo "Data Gagal Diubah !!!";
}
