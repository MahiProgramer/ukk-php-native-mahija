<?php
include "../../conf/conn.php";
$id = $_GET['id'];
$query = ("DELETE FROM barang WHERE id_barang ='$id'");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_barang");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Diupate!";
  echo "Data Gagal Diubah !!!";
}
