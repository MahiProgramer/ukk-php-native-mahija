<?php
include "../../conf/conn.php";
$id    = $_POST['buku'];
$id_admin = $_POST['admin'];
$jumlah = $_POST['jumlah'];
$total = $_POST['total'];
$tanggal = $_POST['tanggal'];
$query = ("INSERT INTO penjualan (id_buku, id_admin, jumlah, total, tanggal) VALUE('$id', '$id_admin', '$jumlah', '$total', '$tanggal')");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_penjualan");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Disimpan!";
  echo "Data Gagal Disimpan !!!";
}