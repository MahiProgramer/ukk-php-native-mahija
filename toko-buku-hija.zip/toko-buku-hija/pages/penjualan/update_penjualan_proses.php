<?php
include "../../conf/conn.php";
$id                  = $_POST['id_penjualan'];
$id_buku      = $_POST['id_buku'];
$id_admin             = $_POST['id_admin$id_admin'];
$jumlah              = $_POST['jumlah'];
$total              = $_POST['total'];
$tanggal              = $_POST['tanggal'];
$query = ("UPDATE penjualan SET id_buku='$id_buku', id_admin$id_admin='$id_admin', jumlah='$jumlah', total='$total', tanggal='$tanggal' WHERE id_penjualan ='$id'");
if ($koneksi->query($query)) {
  //redirect ke halaman index.php 
  //header("location: index.php");
  header("location: ../../index.php?page=data_penjualan");
} else {
  //pesan error gagal update data
  //echo "Data Gagal Diupate!";
  echo "Data Gagal Diubah !!!";
}
